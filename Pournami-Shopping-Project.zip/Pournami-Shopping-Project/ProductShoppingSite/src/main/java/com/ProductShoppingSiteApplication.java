

package com;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductShoppingSiteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductShoppingSiteApplication.class, args);
		
	}

}
