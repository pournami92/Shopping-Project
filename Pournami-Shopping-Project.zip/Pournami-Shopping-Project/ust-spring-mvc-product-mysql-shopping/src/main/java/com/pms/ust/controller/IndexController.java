package com.pms.ust.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class IndexController {
	@RequestMapping("/index")
	public ModelAndView index() {
		ModelAndView view = new ModelAndView();
		view.addObject("username","Tarun");
		view.addObject("password","tarun@123");
		view.setViewName("kapoor");
		return view;
	}

	@RequestMapping("/tufail")
	public String file() {
		return "k";
	}
	
}
