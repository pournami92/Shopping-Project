package com.pms.ust.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.pms.model.Product;
import com.ust.pms.service.ProductService;




@Controller
public class ProductController {
	@Autowired
	ProductService productService;
	
	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		//command
		return new ModelAndView("addProduct","command",new Product());
	}
	@RequestMapping("/saveProduct")
	public String saveProduct(Product product){
		productService.saveProduct(product);
		return "success";
	}	
	@RequestMapping("/cart/{productId}")
	public ModelAndView cartProduct(@PathVariable("productId")String productId) {
		//ModelAndView modelAndView = new ModelAndView();
		//modelAndView.setViewName("searchProductByIdForm");
		//modelAndView.addObject("command",new Product());
		ModelAndView view = new ModelAndView();
		view.addObject("productId",productId);
		return new ModelAndView("cart","command", new Product());
	}
	@RequestMapping("/delete/{productId}")
	public ModelAndView deleteProduct(@PathVariable("productId")String productId) {
		//Integer integer = Integer.valueOf(productId);
		//Integer pId = Integer.valueOf(productId);
		@SuppressWarnings("deprecation")
		Integer pId = new Integer (productId);
		
		productService.deleteProduct(pId);
		ModelAndView view = new ModelAndView();
		view.addObject("productId",productId);
		return new ModelAndView("redirect:/viewAllProducts");
	}
	@RequestMapping("/searchProductForm")
	public ModelAndView searchProductForm() {
		return new ModelAndView( "searchProductForm","command",new Product());
	}
	@RequestMapping("/searchProduct")
	public ModelAndView searchProduct(Product product) {
		ModelAndView view = new ModelAndView();
		view.setViewName("searchProductForm");
		Integer productIdtoSearch = product.getProductId();
	  if(productService.isProductExists(productIdtoSearch)) {
		Product searchProduct = productService.getProduct(productIdtoSearch);
		view.addObject("command", searchProduct);
		System.out.println("Found product details"+searchProduct);
	}else {
		view.addObject("command", new Product());
		view.addObject("message", "Product with product id :"+productIdtoSearch +"does not exists");
		System.out.println("Product with product id:" +productIdtoSearch + "does not exists");
	}
		return view;
	}
	@RequestMapping("/searchProductByIdForm")
	public ModelAndView searchProductByIdForm() {
		return new ModelAndView("searchProductByIdForm", "command" ,new Product());
	}	
	@RequestMapping("/searchProductById")
	public ModelAndView searchProductById(Product product) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		
		int pId = product.getProductId();
		if(productService.isProductExists(pId)) {
			
			Product productDetails = productService.getProduct(pId);
			modelAndView.addObject("command",productDetails);
			//System.out.println("found product details:"+searchProduct);
		}
		else 
		{
			//System.out.println("product with product Id:+productIdtoSearch+" );
			modelAndView.addObject("command",new Product());
			modelAndView.addObject("msg","Product with product id:"+pId+"doesnot exists");
		}
		return modelAndView;
	}
	//delete functionality in spring boot mvc
		@RequestMapping("/deleteProductById")
		public ModelAndView deleteProductById(Product product) {
			ModelAndView modelAndView = new ModelAndView();
			modelAndView.setViewName("searchProductByIdForm");
			modelAndView.addObject("command",new Product());
			int pId = product.getProductId();
			if(productService.isProductExists(pId)) {
				productService.deleteProduct(pId);
				modelAndView.addObject("msg","Product with product id:"+ pId + "deleted");
				//System.out.println("found product details:"+searchProduct);
			}
			else {
				//System.out.println("product with product Id:+productIdtoSearch+" );
				
				modelAndView.addObject("msg","Product with product id:"+ pId + "doesnot exists");
			}
			return modelAndView;
		}
		//Fetch all products
		@RequestMapping("/viewAllProducts")
		public ModelAndView viewAllProducts(){
			List<Product> products = productService.getProducts();
			return new ModelAndView("viewAllProducts", "products" ,products);
		}
}
